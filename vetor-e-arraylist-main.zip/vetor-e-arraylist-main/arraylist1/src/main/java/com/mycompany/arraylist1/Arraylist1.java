/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arraylist1;

/**
 *
 * @author h8s5g
 */

import java.util.ArrayList;

public class Arraylist1 {

public static void main(String[] args) {
    
        ArrayList<String> frutas = new ArrayList<>();

        frutas.add("Maçã");
        frutas.add("Banana");
        frutas.add("Laranja");
        frutas.add("Manga");
        frutas.add("Uva");

        System.out.println("Lista de Frutas: " + frutas);
    }

}
